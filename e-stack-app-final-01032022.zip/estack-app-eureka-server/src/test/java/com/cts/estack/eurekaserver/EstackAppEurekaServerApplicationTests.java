package com.cts.estack.eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstackAppEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
