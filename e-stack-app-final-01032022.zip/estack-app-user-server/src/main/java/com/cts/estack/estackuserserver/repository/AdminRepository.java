package com.cts.estack.estackuserserver.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.estack.estackuserserver.pojo.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>{

	Admin findByEmail(String username);
}