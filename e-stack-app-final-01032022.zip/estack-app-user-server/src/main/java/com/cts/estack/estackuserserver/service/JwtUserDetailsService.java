package com.cts.estack.estackuserserver.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cts.estack.estackuserserver.pojo.Admin;
import com.cts.estack.estackuserserver.repository.AdminRepository;


@Service
public class JwtUserDetailsService implements UserDetailsService {

	@Autowired
	private AdminRepository adminRepository;

	private static int workload = 12;

	public static String hashPassword(String password_plaintext) {
		String salt = BCrypt.gensalt(workload);
		String hashed_password = BCrypt.hashpw(password_plaintext, salt);

		return (hashed_password);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		List<Admin> adminList =adminRepository.findAll();

		System.out.println(adminList);

		boolean adminFound = false;
		for (Admin admin : adminList) {

			if (admin.getEmail().equals(username)) {
				adminFound = true;
				return new User(username, hashPassword(admin.getPassword()), new ArrayList<>());

			}

		}

		if (!adminFound) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return null;

	}

	public static void main(String[] args) {
		System.out.println(hashPassword("password"));
	}
}
