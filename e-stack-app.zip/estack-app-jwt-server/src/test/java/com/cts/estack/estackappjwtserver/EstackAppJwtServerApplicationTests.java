package com.cts.estack.estackappjwtserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstackAppJwtServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
