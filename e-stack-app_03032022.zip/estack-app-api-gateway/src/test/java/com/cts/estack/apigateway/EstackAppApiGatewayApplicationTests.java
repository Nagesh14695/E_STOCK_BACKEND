package com.cts.estack.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstackAppApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
