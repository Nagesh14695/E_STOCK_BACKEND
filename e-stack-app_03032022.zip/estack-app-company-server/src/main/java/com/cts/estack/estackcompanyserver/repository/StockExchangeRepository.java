package com.cts.estack.estackcompanyserver.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.estack.estackcompanyserver.model.StockExchange;

public interface StockExchangeRepository extends JpaRepository<StockExchange, Long> {

	
}
