package com.cts.estack.estackcompanyserver.utils;

public class InvalidRequestException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5254684291329803415L;
	
	public InvalidRequestException(String message) {
		super(message);
	}
	
}
