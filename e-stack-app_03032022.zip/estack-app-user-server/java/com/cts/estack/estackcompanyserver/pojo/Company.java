package com.cts.estack.estackcompanyserver.pojo;

public class Company {

}
