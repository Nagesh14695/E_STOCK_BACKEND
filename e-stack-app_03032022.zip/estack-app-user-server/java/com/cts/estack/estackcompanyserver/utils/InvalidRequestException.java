package com.cts.estack.estackcompanyserver.utils;

public class InvalidRequestException {

}
