package com.cts.estack.estackcompanyserver.repository;

public class StockRepository {

}
