export const environment = {
  production: true,
  HOST: "http://ltin319690",
  port: 9080
};
